﻿#region Copyright
// // -----------------------------------------------------------------------
// // <copyright company="cdmdotnet Limited">
// // 	Copyright cdmdotnet Limited. All rights reserved.
// // </copyright>
// // -----------------------------------------------------------------------
#endregion

using $ext_safeprojectname$.Domain.Host.Configuration;
using $safeprojectname$.Configuration;

namespace $safeprojectname$
{
	public class WebHost : DomainHost<WebHostModule>
	{
		#region Overrides of DomainHost<WebHostModule>

		protected override DomainConfiguration<WebHostModule> GetDomainConfiguration()
		{
			return new WebDomainConfiguration();
		}

		#endregion

		protected override void Run()
		{
		}
	}
}