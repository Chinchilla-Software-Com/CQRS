﻿'use strict';

define(['Scripts/app'], function ()
{
});